window.YTD.email_address_change.part0 = [ {
  "emailAddressChange" : {
    "accountId" : "1371202855726637062",
    "emailChange" : {
      "changedAt" : "2021-03-14T21:02:58.000Z",
      "changedFrom" : "",
      "changedTo" : "marinaa.ateff@gmail.com"
    }
  }
} ]