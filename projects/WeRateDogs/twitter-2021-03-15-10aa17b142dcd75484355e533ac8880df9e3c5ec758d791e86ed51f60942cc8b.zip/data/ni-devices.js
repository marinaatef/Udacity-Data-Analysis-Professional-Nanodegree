window.YTD.ni_devices.part0 = [ {
  "niDeviceResponse" : {
    "messagingDevice" : {
      "deviceType" : "Full",
      "carrier" : "mobinil_eg",
      "phoneNumber" : "+201225758369",
      "createdDate" : "2021.03.14"
    }
  }
} ]