window.YTD.account.part0 = [ {
  "account" : {
    "email" : "marinaa.ateff@gmail.com",
    "createdVia" : "oauth:3033300",
    "username" : "marina53705025",
    "accountId" : "1371202855726637062",
    "createdAt" : "2021-03-14T20:54:21.868Z",
    "accountDisplayName" : "marina"
  }
} ]