window.YTD.device_token.part0 = [ {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "RgiYEvyHClElBLeP8BnHzDrl5LagsaWLuuQQ9eLv",
    "createdAt" : "2021-03-14T20:54:21.988Z",
    "lastSeenAt" : "2021-03-14T20:54:21.989Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
} ]