window.YTD.account_timezone.part0 = [ {
  "accountTimezone" : {
    "accountId" : "1371202855726637062"
  }
} ]